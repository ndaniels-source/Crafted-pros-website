
import React from "react";
import { motion } from "framer-motion";

export default function App() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      <div className="bg-black text-white text-center py-2 text-sm">
        Call Now for a Free Estimate: <a href="tel:9054423573" className="underline">905-442-3573</a>
      </div>

      <section className="text-center py-24 px-6 bg-gradient-to-b from-gray-100 to-white">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl md:text-6xl font-extrabold mb-6"
        >
          Premium Renovations You Can Trust in the Durham Region
        </motion.h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto mb-8">
          Kitchen renovations, bathroom remodels, basement finishing, and full home transformations delivered with precision craftsmanship.
        </p>
        <a href="#contact" className="bg-black text-white px-8 py-3 rounded-2xl">
          Get Your Free Estimate
        </a>
      </section>

      <section id="contact" className="py-20 px-6 text-center">
        <h2 className="text-3xl font-bold mb-6">Request Your Free Quote</h2>
        <form action="https://formspree.io/f/your-form-id" method="POST" className="max-w-xl mx-auto grid gap-4">
          <input name="name" placeholder="Your Name" className="border p-3 rounded" required />
          <input name="email" type="email" placeholder="Your Email" className="border p-3 rounded" required />
          <input name="phone" placeholder="Phone Number" className="border p-3 rounded" />
          <textarea name="message" placeholder="Tell us about your renovation project" className="border p-3 rounded" rows="5"></textarea>
          <button type="submit" className="bg-black text-white py-3 rounded-2xl">
            Submit Request
          </button>
        </form>
      </section>

      <footer className="bg-gray-900 text-white py-6 text-center">
        © {new Date().getFullYear()} Crafted Pro's – Durham Region. All rights reserved.
      </footer>
    </div>
  );
}
